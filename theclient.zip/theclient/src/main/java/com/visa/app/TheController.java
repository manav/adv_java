package com.visa.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Controller
public class TheController {
	
	@Autowired
	GreetClient client;
	
	@RequestMapping("/thegreet")
	@HystrixCommand(fallbackMethod="problemo")
	public String m1(Model m) {
		m.addAttribute("mygreet",client.doGreet());
		
		return "greeting";
	}
	
	public String problemo(Model m)
	{
		m.addAttribute("mygreet","Something bad happened.. call someone");
		return "greeting";
	}

}
