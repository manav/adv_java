package com.visa.app;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient("MICROSERVICE")
public interface GreetClient {
	@RequestMapping("/greeting")
	String doGreet();

}
