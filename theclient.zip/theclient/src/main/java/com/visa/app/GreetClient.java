package com.visa.app;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient("api-gateway")
public interface GreetClient {
	@RequestMapping("/api/greeting")
	String doGreet();

}
