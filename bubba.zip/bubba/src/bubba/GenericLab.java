package bubba;

import java.util.List;

public class GenericLab {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
class Entity{
	private Integer id;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
}
class MyDAO<T extends Entity> {
	public List<T> getAll() {
		return null;
	}

	public T getById(T item) {
		Integer g=item.getId();
		return null;
	}
	
}