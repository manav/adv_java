package bubba;

import java.util.ArrayList;
import java.util.List;

public class Parallel {

	public static void main(String[] args) {
		List<Integer> numlist = new ArrayList<>();
		for (int i = 0; i < 1000; i++) {
			numlist.add(i);
		}
		long start = System.currentTimeMillis();
		numlist.stream().forEach(i -> processData(i));
		long end = System.currentTimeMillis();
		System.out.println("Linear: " + (end - start));

		start = System.currentTimeMillis();
		numlist.parallelStream().forEach(i -> processData(i));
		end = System.currentTimeMillis();
		System.out.println("Parallel: " + (end - start));

	}

	private static void processData(int num) {
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
