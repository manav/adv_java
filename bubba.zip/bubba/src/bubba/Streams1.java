package bubba;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.OptionalDouble;
import java.util.stream.IntStream;

public class Streams1 {

	public static void print1to10(){
		IntStream.range(1,11).forEach(System.out::println);
	}
	public static void printList(List<String> arg) {
		arg.forEach(System.out::println);
	}
	public static List<String> sortMyList(List<String> arg){
		 Collections.sort(arg,(s1,s2) -> s2.length()-s1.length());
         return arg;	
	}
	public static double average(List<Double> d) {
		OptionalDouble ave=null;
		ave=d.stream().mapToDouble(Number::doubleValue)
				.average();
		return ave.getAsDouble();
	}
	public static double max(List<Double> d){
		double max=0;
		max=d.stream().reduce(0.0, Math::max);
		return max;
		
	}
	public static void main(String[] args) {
		print1to10();
		
		List<String> l=Arrays.asList("foo","bar","zoo","sally","bubba");
		printList(l);
		System.out.println("-------");
		sortMyList(l);
		printList(l);
		
		List<Double> doubles=Arrays.asList(0.1,4.5,7.8,3.2,0.9);
		System.out.println("Result-> "+average(doubles));
		System.out.println("Result->" + max(doubles));
	}

}
