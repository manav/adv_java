package bubba;

public interface IHuman {
	public default String name()
	{
		return "Bubba";
	}

}
