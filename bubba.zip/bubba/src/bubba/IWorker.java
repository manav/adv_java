package bubba;

@FunctionalInterface
public interface IWorker {
	void doSomething(String x);
}
