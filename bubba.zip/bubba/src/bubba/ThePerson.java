package bubba;

public class ThePerson implements IPerson{
	
	public String name() {
		return "Perry";
	}

}
