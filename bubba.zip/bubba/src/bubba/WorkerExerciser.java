package bubba;

public class WorkerExerciser {
	private String name;
	public static void execute(IWorker w) {
		w.doSomething("Yo Dawg!");
	}

	public static void main(String[] args) {
		IWorker x = new IWorker() {
			public void doSomething(String x) {
				System.out.println("Inside Worker: " + x);
			}
		};
		execute(x);

		IWorker z = (y) -> System.out.println(
				"Doing the Lambda " + y);
		execute(z);
	}

}
