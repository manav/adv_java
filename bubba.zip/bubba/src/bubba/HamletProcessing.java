package bubba;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.stream.Stream;

public class HamletProcessing {

	public static void main(String[] args) {
		Path txtfile=Paths.get("/Users/jwkidd3/adv_java/hamlet.txt");
		
		try {
			Stream<String> lines=Files.lines(txtfile);
			long count=lines.flatMap(line -> 
			Arrays.stream(line.split(" "))).count();
			System.out.println(count);
					
					
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
