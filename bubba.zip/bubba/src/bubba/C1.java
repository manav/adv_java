package bubba;

import java.util.function.Function;
import static java.lang.System.out;

public class C1 {

	static Function<String, String> f = (name) -> {
		return "Name: " + name;
	};
	static Function<String, Integer> leng = String::length;

	public String name() {
		return "Yo Bubba";
	}

	public static void main(String[] args) {
		String[] strs = { "foo", "bar", "bubba", "bubbas wife", "barry" };
		for (String string : strs) {
			out.println(f.apply(string));

		}
		Function<C1, String> name = C1::name;
		out.println(name.apply(new C1()));
	}

}
