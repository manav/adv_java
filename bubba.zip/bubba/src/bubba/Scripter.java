package bubba;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Scripter {

	public static void main(String[] args) {
		ScriptEngineManager mgr = new ScriptEngineManager();
		ScriptEngine eng = mgr.getEngineByName("nashorn");

		try {
			eng.eval("print('Hello Nashorn!')");
		} catch (ScriptException e) {
			e.printStackTrace();
		}

	}

}
