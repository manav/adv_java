package bubba;

import java.util.ArrayList;
import java.util.List;

public class G {

	public static void main(String[] args) {

		List<? extends Number> l = new ArrayList<>();
		Sally<Integer, Long> sal=new Sally<Integer,Long>(17,89L);
	}
}
class Sally<G,X> {
	private G z;
	private X y;
	
	public Sally(G ig, X iy) {
		this.z=ig;
		this.y=iy;
	}

	public G getZ() {
		return z;
	}

	public void setZ(G z) {
		this.z = z;
	}

	public X getY() {
		return y;
	}

	public void setY(X y) {
		this.y = y;
	}
	
}