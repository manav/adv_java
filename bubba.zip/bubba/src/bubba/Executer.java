package bubba;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class Executer {

	public static void main(String[] args) {
		ScheduledExecutorService svc=Executors.newSingleThreadScheduledExecutor();
		

	}

}
