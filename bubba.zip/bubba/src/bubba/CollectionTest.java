package bubba;

import java.util.LinkedList;
import java.util.List;

public class CollectionTest {

	public static void main(String[] args) {
		List<Integer> list = new LinkedList<>();
		final int counter = 100000;
		int result = 0;
		String str = "";
		StringBuilder sb = new StringBuilder();
		StringBuffer sbuf = new StringBuffer();

		// Add
		long start = System.currentTimeMillis();
		for (int i = 0; i < counter; i++) {
			list.add(i);
		}
		long end = System.currentTimeMillis();
		System.out.println("Add: " + (end - start));

		// Get
		start = System.currentTimeMillis();
		for (int i = 0; i < counter; i++) {
			list.get(i);
		}
		end = System.currentTimeMillis();
		System.out.println("Get: " + (end - start));

		// Remove
		start = System.currentTimeMillis();
		for (int i = 0; i < counter; i++) {
			list.remove(0);
		}
		end = System.currentTimeMillis();
		System.out.println("Remove: " + (end - start));

		// String
		start = System.currentTimeMillis();
		for (int i = 0; i < counter; i++) {
			str += i;
		}
		end = System.currentTimeMillis();
		System.out.println("String Concat: " + (end - start));

		// String Builder
		start = System.currentTimeMillis();
		for (int i = 0; i < counter; i++) {
			sb.append(i);
		}
		end = System.currentTimeMillis();
		System.out.println("String Builder: " + (end - start));

		// String Buffer
		start = System.currentTimeMillis();
		for (int i = 0; i < counter; i++) {
			sbuf.append(i);
		}
		end = System.currentTimeMillis();
		System.out.println("String Concat: " + (end - start));

	}

}
