package bubba;

public interface IPerson {
	public default String name()
	{
		return "Bubba";
	}

}
