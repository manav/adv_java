insert into PURCHASE (CUSTOMERNAME, PRODUCT, PURCHASEDATE)
values('Bruce','Mountain Bike','2010-05-12 00:00:00.0');
insert into PURCHASE (CUSTOMERNAME, PRODUCT, PURCHASEDATE)
values('Paul','Football','2010-04-30 00:00:00.0');
insert into PURCHASE (CUSTOMERNAME, PRODUCT, PURCHASEDATE)
values('Rick','Kayak','2010-06-05 00:00:00.0');
