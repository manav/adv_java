package com.visa;

public interface MyService {
	String greeting();
}
