package com.visa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service("theservice")
public class TheService implements MyService {
	@Value("${message}")
	private String msg;

	@Autowired
	private Environment env;

	@Override
	public String greeting() {

		return msg + ": " + env.getProperty("server.port");
	}

}
