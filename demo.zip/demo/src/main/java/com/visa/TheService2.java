package com.visa;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class TheService2 implements MyService {

	@Override
	public String greeting() {
		return "New Service Impl";
	}

}
